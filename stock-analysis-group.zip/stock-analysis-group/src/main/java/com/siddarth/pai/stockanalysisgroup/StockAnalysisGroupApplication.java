package com.siddarth.pai.stockanalysisgroup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockAnalysisGroupApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockAnalysisGroupApplication.class, args);
	}

}
