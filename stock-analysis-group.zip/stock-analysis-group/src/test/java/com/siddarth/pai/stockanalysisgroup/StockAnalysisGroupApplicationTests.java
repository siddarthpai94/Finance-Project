package com.siddarth.pai.stockanalysisgroup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockAnalysisGroupApplicationTests {

	@Test
	void contextLoads() {
	}

}
